public class Belajar03 {
    public static void main(String[] args) {
        int panjang,lebar,luas,keliling;
        panjang = 10;
        lebar = 15;	
        luas = panjang * lebar;
        System.out.println("luas persegi panjang = " + luas);
        keliling = 2 * (panjang + lebar);
        System.out.println("keliling persegi panjang = " + keliling);
    }
}