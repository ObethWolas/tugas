public class Belajar02 {
    public static void main(String[] args){
        double berat;
        berat = 56;
        System.out.println("Berat awal = " + berat);
        berat = berat + 2;
        System.out.println("Berat setelah makan = " + berat);
        berat = berat - 1;
        System.out.println("Berat setelah olahraga = " + berat);
    }
}