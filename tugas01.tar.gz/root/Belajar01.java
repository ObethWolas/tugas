public class Belajar01 {

     public static void main(String []args){
        System.out.println("Nama: Norberth Wolas");
        System.out.println("NIM: 17220028");
     }
}